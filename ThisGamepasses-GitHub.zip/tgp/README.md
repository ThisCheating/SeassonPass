# ThisGamepasses

Commercial-style Battle Pass plugin for Paper/Purpur 1.20+.

## Requirements
- Java 17+
- Paper/Purpur 1.20+
- Maven 3.9+
- Apollo is optional at runtime
- PlaceholderAPI is optional

## Build locally

```bash
mvn clean package
```

The compiled plugin is generated at:

```text
target/ThisGamepasses-*.jar
```

## GitHub Actions

Every push, pull request, or manual workflow run builds the plugin automatically. The resulting JAR is available under the workflow's **Artifacts** section.
