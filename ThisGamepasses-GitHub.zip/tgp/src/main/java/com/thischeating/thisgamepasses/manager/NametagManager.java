package com.thischeating.thisgamepasses.manager;

import com.thischeating.thisgamepasses.ThisGamepasses;
import com.thischeating.thisgamepasses.model.PassData;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.scoreboard.Scoreboard;
import org.bukkit.scoreboard.Team;

import java.util.HashMap;
import java.util.Map;

public final class NametagManager {
    private final ThisGamepasses plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private final Scoreboard scoreboard = Bukkit.getScoreboardManager().getMainScoreboard();
    private final Map<Integer, Team> teams = new HashMap<>();

    public NametagManager(ThisGamepasses plugin) {
        this.plugin = plugin;
        int max = plugin.getConfig().getInt("settings.max-level", 30);
        for (int level = 0; level <= max; level++) {
            String name = "tgplv" + level;
            Team team = scoreboard.getTeam(name);
            if (team == null) team = scoreboard.registerNewTeam(name);
            team.setOption(Team.Option.NAME_TAG_VISIBILITY, Team.OptionStatus.ALWAYS);
            teams.put(level, team);
        }
    }

    public void refresh(Player player) {
        if (!plugin.getConfig().getBoolean("nametag.enabled", true)) return;
        PassData data = plugin.getPassManager().get(player);
        if (data == null) return;
        remove(player);
        Team team = teams.get(Math.min(data.level(), plugin.getPassManager().maxLevel()));
        if (team == null) return;
        String format = plugin.getConfig().getString("nametag.format", "[Nivel %level%] %player_name%");
        format = format.replace("%level%", String.valueOf(data.level())).replace("%player_name%", player.getName());
        Component component = mini.deserialize(format);
        // Team prefix is the vanilla/Paper fallback. Apollo can override it for Lunar clients.
        team.prefix(component.append(Component.text(" ")));
        team.addEntry(player.getName());
    }

    public void remove(Player player) {
        for (Team team : teams.values()) team.removeEntry(player.getName());
    }
}
