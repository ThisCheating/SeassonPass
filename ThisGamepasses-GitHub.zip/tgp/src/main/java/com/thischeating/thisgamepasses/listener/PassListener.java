package com.thischeating.thisgamepasses.listener;

import com.thischeating.thisgamepasses.ThisGamepasses;
import org.bukkit.Material;
import org.bukkit.entity.Animals;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.event.entity.EntityBreedEvent;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.player.PlayerFishEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

import java.util.Set;

public final class PassListener implements Listener {
    private final ThisGamepasses plugin;
    private final Set<Material> ores = Set.of(Material.COAL_ORE,Material.DEEPSLATE_COAL_ORE,Material.IRON_ORE,Material.DEEPSLATE_IRON_ORE,Material.GOLD_ORE,Material.DEEPSLATE_GOLD_ORE,Material.COPPER_ORE,Material.DEEPSLATE_COPPER_ORE,Material.REDSTONE_ORE,Material.DEEPSLATE_REDSTONE_ORE,Material.LAPIS_ORE,Material.DEEPSLATE_LAPIS_ORE,Material.DIAMOND_ORE,Material.DEEPSLATE_DIAMOND_ORE,Material.EMERALD_ORE,Material.DEEPSLATE_EMERALD_ORE,Material.NETHER_GOLD_ORE,Material.NETHER_QUARTZ_ORE);
    public PassListener(ThisGamepasses plugin){this.plugin=plugin;}
    @EventHandler public void join(PlayerJoinEvent e){plugin.getPassManager().load(e.getPlayer());}
    @EventHandler public void quit(PlayerQuitEvent e){plugin.getPassManager().unload(e.getPlayer().getUniqueId());}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void breakBlock(BlockBreakEvent e){if(ores.contains(e.getBlock().getType()))plugin.getPassManager().addXp(e.getPlayer(),plugin.getConfig().getLong("xp.block-break",5));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void kill(EntityDeathEvent e){Player p=e.getEntity().getKiller();if(p!=null)plugin.getPassManager().addXp(p,plugin.getConfig().getLong("xp.mob-kill",10));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void fish(PlayerFishEvent e){if(e.getState()==PlayerFishEvent.State.CAUGHT_FISH)plugin.getPassManager().addXp(e.getPlayer(),plugin.getConfig().getLong("xp.fishing",20));}
    @EventHandler(priority=EventPriority.MONITOR,ignoreCancelled=true) public void breed(EntityBreedEvent e){if(e.getBreeder() instanceof Player p)plugin.getPassManager().addXp(p,plugin.getConfig().getLong("xp.breeding",25));}
    @EventHandler public void click(InventoryClickEvent e){if(e.getView().getTitle().contains("Pase de Batalla") || e.getView().title().toString().contains("Pase de Batalla"))plugin.getGui().click(e);}
}
