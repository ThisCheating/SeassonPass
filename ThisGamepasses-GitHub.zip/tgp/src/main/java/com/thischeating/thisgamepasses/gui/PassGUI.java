package com.thischeating.thisgamepasses.gui;

import com.thischeating.thisgamepasses.ThisGamepasses;
import com.thischeating.thisgamepasses.model.PassData;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public final class PassGUI {
    private final ThisGamepasses plugin;
    private final MiniMessage mini = MiniMessage.miniMessage();
    private final int[] slots = {9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35,36,37,38};
    public PassGUI(ThisGamepasses plugin) { this.plugin = plugin; }

    public void open(Player player) {
        PassData d = plugin.getPassManager().get(player);
        if (d == null) return;
        String title = plugin.getConfig().getString("gui.title", "Pase de Batalla").replace("%player_name%", player.getName());
        Inventory inv = Bukkit.createInventory(player, 54, mini.deserialize(title));
        Material filler = material("gui.filler", Material.BLACK_STAINED_GLASS_PANE);
        for (int i=0;i<54;i++) inv.setItem(i, item(filler, "<dark_gray> </dark_gray>", List.of()));
        int max = plugin.getPassManager().maxLevel();
        for (int level=1; level<=Math.min(max, slots.length); level++) inv.setItem(slots[level-1], levelItem(player,d,level));
        player.openInventory(inv);
    }

    private ItemStack levelItem(Player p, PassData d, int level) {
        boolean unlocked = d.level() >= level;
        boolean premium = p.hasPermission("thisgamepasses.premium");
        ConfigurationSection section = plugin.getConfig().getConfigurationSection("rewards."+level);
        Material mat = material(unlocked ? "gui.level-item" : "gui.locked-item", Material.EXPERIENCE_BOTTLE);
        List<String> lore = new ArrayList<>();
        lore.add("<gray>Nivel <white>"+level+"</white></gray>");
        lore.add(unlocked ? plugin.getConfig().getString("gui.free-label", "<green>GRATIS</green>") : plugin.getConfig().getString("gui.locked-label", "<red>BLOQUEADO</red>"));
        if (section != null && section.isConfigurationSection("free")) {
            lore.add("<gray>• </gray>"+section.getString("free.name", "Recompensa gratuita"));
            lore.add("<dark_gray>Click para reclamar</dark_gray>");
        }
        lore.add(premium ? plugin.getConfig().getString("gui.premium-label", "<gold>PREMIUM</gold>") : "<gold>PREMIUM <dark_gray>(permiso requerido)</dark_gray>");
        if (section != null && section.isConfigurationSection("premium")) lore.add("<gray>• </gray>"+section.getString("premium.name", "Recompensa premium"));
        ItemStack item = item(mat, "<gold><bold>Nivel "+level+"</bold></gold>", lore);
        ItemMeta meta = item.getItemMeta(); meta.getPersistentDataContainer().set(plugin.getLevelKey(), org.bukkit.persistence.PersistentDataType.INTEGER, level); item.setItemMeta(meta);
        return item;
    }

    private ItemStack item(Material m, String name, List<String> lore) {
        ItemStack i = new ItemStack(m); ItemMeta meta=i.getItemMeta(); meta.displayName(mini.deserialize(name)); meta.lore(lore.stream().map(mini::deserialize).toList()); i.setItemMeta(meta); return i;
    }
    private Material material(String path, Material fallback) { Material m=Material.matchMaterial(plugin.getConfig().getString(path,"")); return m==null?fallback:m; }

    public void click(InventoryClickEvent e) {
        if (!(e.getWhoClicked() instanceof Player p)) return;
        if (e.getClickedInventory() == null || e.getCurrentItem() == null) return;
        Integer level=e.getCurrentItem().getItemMeta().getPersistentDataContainer().get(plugin.getLevelKey(), org.bukkit.persistence.PersistentDataType.INTEGER);
        if(level==null) return;
        e.setCancelled(true);
        boolean premium = e.isRightClick();
        claim(p, level, premium);
        plugin.getServer().getScheduler().runTask(plugin, () -> open(p));
    }
    private void claim(Player p,int level,boolean premium) {
        PassData d=plugin.getPassManager().get(p); if(d==null || d.level()<level) return;
        if(premium && !p.hasPermission("thisgamepasses.premium")) return;
        if(d.claimed(premium,level)) return;
        ConfigurationSection s=plugin.getConfig().getConfigurationSection("rewards."+level+"."+(premium?"premium":"free")); if(s==null)return;
        ItemStack reward=plugin.getCosmeticManager().create(s);
        if(p.getInventory().firstEmpty()==-1){p.sendMessage(plugin.message("reward-locked"));return;}
        p.getInventory().addItem(reward); d.claim(premium,level); plugin.getPassManager().save(d); p.sendMessage(plugin.message("reward-claimed"));
        if(premium) plugin.getApollo().ifPresent(a->a.notifyLevelUp(p, level));
    }
}
