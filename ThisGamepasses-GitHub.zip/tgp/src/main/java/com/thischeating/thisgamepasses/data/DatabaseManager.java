package com.thischeating.thisgamepasses.data;

import com.thischeating.thisgamepasses.model.PassData;
import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;
import org.bukkit.configuration.file.FileConfiguration;

import java.io.File;
import java.sql.*;
import java.util.UUID;
import java.util.concurrent.CompletableFuture;

public final class DatabaseManager {
    private final File dataFolder;
    private final FileConfiguration config;
    private HikariDataSource dataSource;

    public DatabaseManager(File dataFolder, FileConfiguration config) { this.dataFolder = dataFolder; this.config = config; }

    public void start() throws SQLException {
        String type = config.getString("settings.database.type", "sqlite").toLowerCase();
        HikariConfig hc = new HikariConfig();
        hc.setMaximumPoolSize(Math.max(2, config.getInt("settings.database.mysql.pool-size", 10)));
        hc.setPoolName("ThisGamepasses-Pool");
        if (type.equals("mysql")) {
            String host = config.getString("settings.database.mysql.host", "localhost");
            int port = config.getInt("settings.database.mysql.port", 3306);
            String db = config.getString("settings.database.mysql.database", "thisgamepasses");
            hc.setJdbcUrl("jdbc:mysql://" + host + ":" + port + "/" + db + "?useSSL=false&serverTimezone=UTC");
            hc.setUsername(config.getString("settings.database.mysql.username", "root"));
            hc.setPassword(config.getString("settings.database.mysql.password", ""));
        } else {
            File db = new File(dataFolder, config.getString("settings.database.file", "players.db"));
            hc.setJdbcUrl("jdbc:sqlite:" + db.getAbsolutePath());
            hc.setMaximumPoolSize(1);
        }
        dataSource = new HikariDataSource(hc);
        try (Connection c = dataSource.getConnection(); Statement s = c.createStatement()) {
            s.executeUpdate("CREATE TABLE IF NOT EXISTS thisgamepasses_players (uuid VARCHAR(36) PRIMARY KEY, level INT NOT NULL DEFAULT 0, xp BIGINT NOT NULL DEFAULT 0, claimed_free TEXT NOT NULL DEFAULT '', claimed_premium TEXT NOT NULL DEFAULT '')");
        }
    }

    public CompletableFuture<PassData> load(UUID uuid) {
        return CompletableFuture.supplyAsync(() -> {
            try (Connection c = dataSource.getConnection(); PreparedStatement p = c.prepareStatement("SELECT level,xp,claimed_free,claimed_premium FROM thisgamepasses_players WHERE uuid=?")) {
                p.setString(1, uuid.toString());
                try (ResultSet r = p.executeQuery()) {
                    if (r.next()) return new PassData(uuid, r.getInt(1), r.getLong(2), r.getString(3), r.getString(4));
                }
                try (PreparedStatement ins = c.prepareStatement("INSERT INTO thisgamepasses_players(uuid) VALUES(?)")) { ins.setString(1, uuid.toString()); ins.executeUpdate(); }
                return new PassData(uuid, 0, 0, "", "");
            } catch (SQLException e) { throw new RuntimeException(e); }
        });
    }

    public CompletableFuture<Void> save(PassData d) {
        return CompletableFuture.runAsync(() -> {
            String sql = "REPLACE INTO thisgamepasses_players(uuid,level,xp,claimed_free,claimed_premium) VALUES(?,?,?,?,?)";
            // MySQL and SQLite both support this form on current supported versions.
            try (Connection c = dataSource.getConnection(); PreparedStatement p = c.prepareStatement(sql)) {
                p.setString(1, d.uuid().toString()); p.setInt(2, d.level()); p.setLong(3, d.xp());
                p.setString(4, d.serialize(d.claimedFree())); p.setString(5, d.serialize(d.claimedPremium())); p.executeUpdate();
            } catch (SQLException e) { throw new RuntimeException(e); }
        });
    }

    public CompletableFuture<Void> reset(UUID uuid) {
        return CompletableFuture.runAsync(() -> {
            try (Connection c = dataSource.getConnection(); PreparedStatement p = c.prepareStatement("UPDATE thisgamepasses_players SET level=0,xp=0,claimed_free='',claimed_premium='' WHERE uuid=?")) {
                p.setString(1, uuid.toString()); p.executeUpdate();
            } catch (SQLException e) { throw new RuntimeException(e); }
        });
    }
    public void close() { if (dataSource != null) dataSource.close(); }
}
