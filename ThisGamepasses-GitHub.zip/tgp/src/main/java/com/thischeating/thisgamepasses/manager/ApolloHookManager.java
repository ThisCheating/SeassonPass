package com.thischeating.thisgamepasses.manager;

import com.thischeating.thisgamepasses.ThisGamepasses;
import net.kyori.adventure.text.Component;
import org.bukkit.Color;
import org.bukkit.Location;
import org.bukkit.entity.Player;

import java.lang.reflect.Method;
import java.time.Duration;
import java.util.UUID;

/**
 * Apollo is compiled as provided and this class is only loaded when Apollo-Bukkit exists.
 * Keeping every Apollo reference here prevents ClassNotFoundException on servers without Apollo.
 */
public final class ApolloHookManager {
    private final ThisGamepasses plugin;
    private Object notificationModule;
    private Object cooldownModule;
    private Object waypointModule;
    private Object glowModule;
    private Object nametagModule;

    public ApolloHookManager(ThisGamepasses plugin) {
        this.plugin = plugin;
        try {
            Class<?> apollo = Class.forName("com.lunarclient.apollo.Apollo");
            Method getModules = apollo.getMethod("getModuleManager");
            Object manager = getModules.invoke(null);
            notificationModule = module(manager, "com.lunarclient.apollo.module.notification.NotificationModule");
            cooldownModule = module(manager, "com.lunarclient.apollo.module.cooldown.CooldownModule");
            waypointModule = module(manager, "com.lunarclient.apollo.module.waypoint.WaypointModule");
            glowModule = module(manager, "com.lunarclient.apollo.module.glow.GlowModule");
            nametagModule = module(manager, "com.lunarclient.apollo.module.nametag.NametagModule");
        } catch (Throwable t) {
            plugin.getLogger().warning("Apollo detectado pero no pudo inicializarse: " + t.getClass().getSimpleName());
        }
    }

    private Object module(Object manager, String className) throws Exception {
        Class<?> type = Class.forName(className);
        return manager.getClass().getMethod("getModule", Class.class).invoke(manager, type);
    }

    private Object apolloPlayer(Player player) throws Exception {
        Class<?> apollo = Class.forName("com.lunarclient.apollo.Apollo");
        Object pm = apollo.getMethod("getPlayerManager").invoke(null);
        return ((java.util.Optional<?>) pm.getClass().getMethod("getPlayer", UUID.class).invoke(pm, player.getUniqueId())).orElse(null);
    }
    private Object recipientsEveryone() throws Exception {
        Class<?> r = Class.forName("com.lunarclient.apollo.recipients.Recipients");
        return r.getMethod("ofEveryone").invoke(null);
    }
    public boolean supports(Player player) {
        try {
            Class<?> apollo = Class.forName("com.lunarclient.apollo.Apollo");
            Object pm = apollo.getMethod("getPlayerManager").invoke(null);
            return (boolean) pm.getClass().getMethod("hasSupport", UUID.class).invoke(pm, player.getUniqueId());
        } catch (Throwable ignored) { return false; }
    }

    private Object invoke(Object target, String name, Object... args) throws Exception {
        for (Method m : target.getClass().getMethods()) {
            if (!m.getName().equals(name) || m.getParameterCount() != args.length) continue;
            Class<?>[] types = m.getParameterTypes(); boolean ok = true;
            for (int i = 0; i < types.length; i++) if (args[i] != null && !types[i].isAssignableFrom(args[i].getClass())) { ok = false; break; }
            if (ok) return m.invoke(target, args);
        }
        throw new NoSuchMethodException(name);
    }

    public void updateNametag(Player player, String text) {
        if (!supports(player) || nametagModule == null) return;
        try {
            Object recipients = recipientsEveryone();
            Class<?> n = Class.forName("com.lunarclient.apollo.module.nametag.Nametag");
            Object builder = n.getMethod("builder").invoke(null);
            java.util.List<Component> lines = java.util.List.of(Component.text(text));
            builder = invoke(builder, "lines", lines);
            Class<?> vis = Class.forName("com.lunarclient.apollo.module.nametag.NametagVisibilityOverride");
            builder = invoke(builder, "visibilityOverride", Enum.valueOf((Class<Enum>) vis.asSubclass(Enum.class), "NONE"));
            Object tag = invoke(builder, "build");
            invoke(nametagModule, "overrideNametag", recipients, player.getUniqueId(), tag);
        } catch (Throwable ignored) {}
    }

    public void notifyLevelUp(Player player, int level) {
        if (!plugin.getConfig().getBoolean("apollo.notification.enabled", true) || !supports(player) || notificationModule == null) return;
        try {
            Object ap = apolloPlayer(player); if (ap == null) return;
            Class<?> n = Class.forName("com.lunarclient.apollo.module.notification.Notification");
            Object builder = n.getMethod("builder").invoke(null);
            builder = builder.getClass().getMethod("titleComponent", Component.class).invoke(builder, Component.text(plugin.getConfig().getString("apollo.notification.title", "ThisPass")));
            builder = builder.getClass().getMethod("descriptionComponent", Component.class).invoke(builder, Component.text("¡Nivel " + level + " alcanzado!"));
            builder = builder.getClass().getMethod("displayTime", Duration.class).invoke(builder, Duration.ofSeconds(plugin.getConfig().getLong("apollo.notification.display-seconds", 4)));
            Object notification = builder.getClass().getMethod("build").invoke(builder);
            invoke(notificationModule, "displayNotification", ap, notification);
        } catch (Throwable ignored) {}
    }

    public void showCooldown(Player player) {
        if (!plugin.getConfig().getBoolean("apollo.cooldown.enabled", true) || !supports(player) || cooldownModule == null) return;
        try {
            Object ap = apolloPlayer(player); if (ap == null) return;
            Class<?> c = Class.forName("com.lunarclient.apollo.module.cooldown.Cooldown");
            Class<?> icon = Class.forName("com.lunarclient.apollo.module.cooldown.icon.ItemStackIcon");
            Object ib = icon.getMethod("builder").invoke(null);
            ib = ib.getClass().getMethod("itemName", String.class).invoke(ib, "EXPERIENCE_BOTTLE");
            Object io = ib.getClass().getMethod("build").invoke(ib);
            Object cb = c.getMethod("builder").invoke(null);
            cb = cb.getClass().getMethod("name", String.class).invoke(cb, plugin.getConfig().getString("apollo.cooldown.name", "thisgamepasses-xp"));
            cb = cb.getClass().getMethod("duration", Duration.class).invoke(cb, Duration.ofSeconds(plugin.getConfig().getLong("apollo.cooldown.seconds", 3)));
            cb = cb.getClass().getMethod("icon", icon).invoke(cb, io);
            Object co = cb.getClass().getMethod("build").invoke(cb);
            invoke(cooldownModule, "displayCooldown", ap, co);
        } catch (Throwable ignored) {}
    }

    public void waypoint(Player player, Location location) {
        if (!plugin.getConfig().getBoolean("apollo.waypoint.enabled", true) || !supports(player) || waypointModule == null) return;
        try {
            Object ap = apolloPlayer(player); if (ap == null) return;
            Class<?> w = Class.forName("com.lunarclient.apollo.module.waypoint.Waypoint");
            Class<?> bl = Class.forName("com.lunarclient.apollo.common.location.ApolloBlockLocation");
            Object lb = bl.getMethod("builder").invoke(null);
            lb = lb.getClass().getMethod("world", String.class).invoke(lb, location.getWorld().getName());
            lb = lb.getClass().getMethod("x", int.class).invoke(lb, location.getBlockX());
            lb = lb.getClass().getMethod("y", int.class).invoke(lb, location.getBlockY());
            lb = lb.getClass().getMethod("z", int.class).invoke(lb, location.getBlockZ());
            Object loc = lb.getClass().getMethod("build").invoke(lb);
            Object wb = w.getMethod("builder").invoke(null);
            wb = wb.getClass().getMethod("name", String.class).invoke(wb, plugin.getConfig().getString("apollo.waypoint.name", "Pase de Batalla"));
            wb = wb.getClass().getMethod("location", bl).invoke(wb, loc);
            wb = wb.getClass().getMethod("color", java.awt.Color.class).invoke(wb, java.awt.Color.decode(plugin.getConfig().getString("apollo.waypoint.color", "#FFAA00")));
            wb = wb.getClass().getMethod("preventRemoval", boolean.class).invoke(wb, false);
            wb = wb.getClass().getMethod("hidden", boolean.class).invoke(wb, false);
            Object wp = wb.getClass().getMethod("build").invoke(wb);
            invoke(waypointModule, "displayWaypoint", ap, wp);
        } catch (Throwable ignored) {}
    }

    public void glow(Player player) {
        if (!plugin.getConfig().getBoolean("apollo.glow.enabled", true) || !supports(player) || glowModule == null) return;
        try {
            Object recipients = recipientsEveryone();
            invoke(glowModule, "overrideGlow", recipients, player.getUniqueId(), java.awt.Color.decode(plugin.getConfig().getString("apollo.glow.color", "#FFAA00")));
        } catch (Throwable ignored) {}
    }
}
