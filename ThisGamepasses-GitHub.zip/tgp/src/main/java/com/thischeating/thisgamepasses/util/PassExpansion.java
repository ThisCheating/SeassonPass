package com.thischeating.thisgamepasses.util;

import com.thischeating.thisgamepasses.ThisGamepasses;
import com.thischeating.thisgamepasses.model.PassData;
import me.clip.placeholderapi.expansion.PlaceholderExpansion;
import org.bukkit.entity.Player;

public final class PassExpansion extends PlaceholderExpansion {
    private final ThisGamepasses plugin;
    public PassExpansion(ThisGamepasses plugin){this.plugin=plugin;}
    @Override public String getIdentifier(){return "thisgamepasses";}
    @Override public String getAuthor(){return "ThisCheating";}
    @Override public String getVersion(){return plugin.getDescription().getVersion();}
    @Override public boolean persist(){return true;}
    @Override public String onPlaceholderRequest(Player p,String params){if(p==null)return "";PassData d=plugin.getPassManager().get(p);if(d==null)return "0";return switch(params.toLowerCase()){case "level"->String.valueOf(d.level());case "xp"->String.valueOf(d.xp());case "required_xp"->String.valueOf(plugin.getPassManager().xpPerLevel());case "progress"->String.format("%.1f",(d.xp()%(plugin.getPassManager().xpPerLevel()))*100.0/plugin.getPassManager().xpPerLevel());default->null;};}
}
