package com.thischeating.thisgamepasses.model;

import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

public final class PassData {
    private final UUID uuid;
    private int level;
    private long xp;
    private final Set<Integer> claimedFree = new HashSet<>();
    private final Set<Integer> claimedPremium = new HashSet<>();

    public PassData(UUID uuid, int level, long xp, String free, String premium) {
        this.uuid = uuid;
        this.level = Math.max(0, level);
        this.xp = Math.max(0, xp);
        parse(free, claimedFree);
        parse(premium, claimedPremium);
    }
    private static void parse(String raw, Set<Integer> target) {
        if (raw == null || raw.isBlank()) return;
        for (String s : raw.split(",")) try { target.add(Integer.parseInt(s)); } catch (NumberFormatException ignored) {}
    }
    public UUID uuid() { return uuid; }
    public int level() { return level; }
    public long xp() { return xp; }
    public void level(int value) { level = Math.max(0, value); }
    public void xp(long value) { xp = Math.max(0, value); }
    public Set<Integer> claimedFree() { return claimedFree; }
    public Set<Integer> claimedPremium() { return claimedPremium; }
    public boolean claimed(boolean premium, int level) { return (premium ? claimedPremium : claimedFree).contains(level); }
    public void claim(boolean premium, int level) { (premium ? claimedPremium : claimedFree).add(level); }
    public String serialize(Set<Integer> values) { return values.stream().sorted().map(String::valueOf).reduce((a,b)->a+","+b).orElse(""); }
}
