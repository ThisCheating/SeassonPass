package com.thischeating.thisgamepasses.manager;

import com.thischeating.thisgamepasses.ThisGamepasses;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

public final class CosmeticManager {
    private final NamespacedKey cosmeticKey;
    public CosmeticManager(ThisGamepasses plugin) { cosmeticKey = new NamespacedKey(plugin, "cosmetic"); }

    public ItemStack create(ConfigurationSection section) {
        Material material = Material.matchMaterial(section.getString("material", "PAPER"));
        if (material == null) material = Material.PAPER;
        ItemStack item = new ItemStack(material, Math.max(1, section.getInt("amount", 1)));
        ItemMeta meta = item.getItemMeta();
        String name = section.getString("name");
        if (name != null) meta.displayName(net.kyori.adventure.text.minimessage.MiniMessage.miniMessage().deserialize(name));
        if (section.contains("custom-model-data")) meta.setCustomModelData(section.getInt("custom-model-data"));
        if (section.getBoolean("cosmetic", false)) meta.getPersistentDataContainer().set(cosmeticKey, PersistentDataType.STRING, "thisgamepasses");
        item.setItemMeta(meta);
        return item;
    }

    public boolean isCosmetic(ItemStack item) {
        return item != null && item.hasItemMeta() && item.getItemMeta().getPersistentDataContainer().has(cosmeticKey, PersistentDataType.STRING);
    }
    public void equipHead(Player player, ItemStack item) { player.getInventory().setHelmet(item.clone()); }
    public void clearHead(Player player) { player.getInventory().setHelmet(null); }
}
