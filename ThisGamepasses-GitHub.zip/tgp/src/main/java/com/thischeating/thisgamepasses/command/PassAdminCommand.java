package com.thischeating.thisgamepasses.command;

import com.thischeating.thisgamepasses.ThisGamepasses;
import org.bukkit.Bukkit;
import org.bukkit.command.*;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public final class PassAdminCommand implements CommandExecutor, TabCompleter {
    private final ThisGamepasses plugin;
    public PassAdminCommand(ThisGamepasses plugin){this.plugin=plugin;}
    public boolean onCommand(CommandSender s, Command c, String label, String[] a){
        if(a.length==0){if(!(s instanceof Player p)){s.sendMessage(plugin.message("player-only"));return true;} plugin.getGui().open(p);return true;}
        String sub=a[0].toLowerCase();
        if(sub.equals("reload")){if(!s.hasPermission("thisgamepasses.admin.reload")){s.sendMessage(plugin.message("no-permission"));return true;}plugin.reloadPluginConfig();s.sendMessage(plugin.message("reloaded"));return true;}
        if(a.length<2){s.sendMessage(plugin.message("usage"));return true;}
        Player target=Bukkit.getPlayerExact(a[1]); if(target==null){s.sendMessage(plugin.message("player-not-found"));return true;}
        try{
            switch(sub){
                case "givelevel" -> {if(!s.hasPermission("thisgamepasses.admin.givelevel")){s.sendMessage(plugin.message("no-permission"));return true;} plugin.getPassManager().giveLevels(target,Integer.parseInt(a[2]));}
                case "setlevel" -> {if(!s.hasPermission("thisgamepasses.admin.setlevel")){s.sendMessage(plugin.message("no-permission"));return true;} plugin.getPassManager().setLevel(target,Integer.parseInt(a[2]));}
                case "addxp" -> {if(!s.hasPermission("thisgamepasses.admin.addxp")){s.sendMessage(plugin.message("no-permission"));return true;} plugin.getPassManager().addXp(target,Long.parseLong(a[2]));}
                case "reset" -> {if(!s.hasPermission("thisgamepasses.admin.reset")){s.sendMessage(plugin.message("no-permission"));return true;} plugin.getPassManager().reset(target);}
                default -> s.sendMessage(plugin.message("usage"));
            }
        }catch(NumberFormatException|ArrayIndexOutOfBoundsException ex){s.sendMessage(plugin.message("invalid-number"));}
        return true;
    }
    public List<String> onTabComplete(CommandSender s,Command c,String alias,String[] a){
        if(a.length==1)return filter(List.of("givelevel","setlevel","addxp","reset","reload"),a[0]);
        if(a.length==2 && !a[0].equalsIgnoreCase("reload"))return filter(Bukkit.getOnlinePlayers().stream().map(Player::getName).toList(),a[1]);
        if(a.length==3 && (a[0].equalsIgnoreCase("givelevel")||a[0].equalsIgnoreCase("setlevel")||a[0].equalsIgnoreCase("addxp")))return List.of("1","5","10");
        return List.of();
    }
    private List<String> filter(List<String> values,String q){List<String> r=new ArrayList<>();for(String v:values)if(v.toLowerCase().startsWith(q.toLowerCase()))r.add(v);return r;}
}
