package com.thischeating.thisgamepasses.manager;

import com.thischeating.thisgamepasses.ThisGamepasses;
import com.thischeating.thisgamepasses.data.DatabaseManager;
import com.thischeating.thisgamepasses.model.PassData;
import org.bukkit.entity.Player;

import java.util.Map;
import java.util.UUID;
import java.util.concurrent.ConcurrentHashMap;

public final class PassManager {
    private final ThisGamepasses plugin;
    private final DatabaseManager database;
    private final Map<UUID, PassData> cache = new ConcurrentHashMap<>();

    public PassManager(ThisGamepasses plugin, DatabaseManager database) { this.plugin = plugin; this.database = database; }
    public void load(Player player) {
        database.load(player.getUniqueId()).thenAccept(data -> plugin.getServer().getScheduler().runTask(plugin, () -> cache.put(player.getUniqueId(), data)));
    }
    public PassData get(UUID uuid) { return cache.get(uuid); }
    public PassData get(Player p) { return get(p.getUniqueId()); }
    public void unload(UUID uuid) { PassData d = cache.remove(uuid); if (d != null) database.save(d); }
    public void save(PassData d) { database.save(d); }

    public int maxLevel() { return plugin.getConfig().getInt("settings.max-level", 30); }
    public long xpPerLevel() { return plugin.getConfig().getLong("settings.xp-per-level", 1000); }
    public long requiredXp(PassData d) { return (long) d.level() * xpPerLevel(); }

    public void addXp(Player player, long amount) {
        PassData d = get(player); if (d == null || amount <= 0) return;
        long oldXp = d.xp();
        d.xp(Math.min((long) maxLevel() * xpPerLevel(), oldXp + amount));
        int oldLevel = d.level();
        while (d.level() < maxLevel() && d.xp() >= requiredXp(d) + xpPerLevel()) d.level(d.level() + 1);
        if (d.level() > oldLevel) {
            for (int level = oldLevel + 1; level <= d.level(); level++) plugin.handleLevelUp(player, level);
        }
        database.save(d);
        plugin.refreshPlayer(player);
    }
    public void setLevel(Player player, int level) {
        PassData d = get(player); if (d == null) return;
        d.level(Math.max(0, Math.min(maxLevel(), level)));
        d.xp(Math.min(d.xp(), (long) maxLevel() * xpPerLevel()));
        database.save(d); plugin.refreshPlayer(player);
    }
    public void giveLevels(Player player, int levels) { PassData d=get(player); if(d==null)return; setLevel(player, d.level()+levels); }
    public void reset(Player player) { PassData d=get(player); if(d==null)return; d.level(0); d.xp(0); d.claimedFree().clear(); d.claimedPremium().clear(); database.save(d); plugin.refreshPlayer(player); }
}
