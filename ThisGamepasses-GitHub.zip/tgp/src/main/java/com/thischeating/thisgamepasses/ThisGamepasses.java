package com.thischeating.thisgamepasses;

import com.thischeating.thisgamepasses.command.PassAdminCommand;
import com.thischeating.thisgamepasses.data.DatabaseManager;
import com.thischeating.thisgamepasses.gui.PassGUI;
import com.thischeating.thisgamepasses.listener.PassListener;
import com.thischeating.thisgamepasses.manager.ApolloHookManager;
import com.thischeating.thisgamepasses.manager.CosmeticManager;
import com.thischeating.thisgamepasses.manager.NametagManager;
import com.thischeating.thisgamepasses.manager.PassManager;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.minimessage.MiniMessage;
import org.bukkit.Bukkit;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.Optional;
import com.thischeating.thisgamepasses.util.PassExpansion;

public final class ThisGamepasses extends JavaPlugin {
    private final MiniMessage mini = MiniMessage.miniMessage();
    private DatabaseManager database;
    private PassManager passManager;
    private NametagManager nametagManager;
    private CosmeticManager cosmeticManager;
    private PassGUI gui;
    private ApolloHookManager apollo;
    private NamespacedKey levelKey;

    @Override public void onEnable() {
        saveDefaultConfig();
        levelKey = new NamespacedKey(this,"pass-level");
        try { database = new DatabaseManager(getDataFolder(),getConfig()); database.start(); }
        catch(Exception e){getLogger().severe("No se pudo iniciar la base de datos: "+e.getMessage());getServer().getPluginManager().disablePlugin(this);return;}
        passManager=new PassManager(this,database); nametagManager=new NametagManager(this); cosmeticManager=new CosmeticManager(this); gui=new PassGUI(this);
        if(getConfig().getBoolean("apollo.enabled",true) && getServer().getPluginManager().getPlugin("Apollo-Bukkit")!=null){
            try { apollo=new ApolloHookManager(this); getLogger().info("Apollo integrado correctamente."); } catch(Throwable t){getLogger().warning("Apollo no pudo inicializarse: "+t.getMessage());}
        }
        PassAdminCommand command=new PassAdminCommand(this); getCommand("pass").setExecutor(command); getCommand("pass").setTabCompleter(command);
        getServer().getPluginManager().registerEvents(new PassListener(this),this);
        if(getServer().getPluginManager().getPlugin("PlaceholderAPI")!=null){try{new PassExpansion(this).register();getLogger().info("PlaceholderAPI expansion registrada.");}catch(Throwable ignored){}}
        long ticks=Math.max(20,getConfig().getLong("settings.autosave-seconds",30)*20L);
        getServer().getScheduler().runTaskTimerAsynchronously(this,()->getServer().getOnlinePlayers().forEach(p->{var d=passManager.get(p);if(d!=null)database.save(d);}),ticks,ticks);
        Bukkit.getOnlinePlayers().forEach(passManager::load);
        getLogger().info("ThisGamepasses habilitado.");
    }
    @Override public void onDisable(){if(passManager!=null)Bukkit.getOnlinePlayers().forEach(p->passManager.unload(p.getUniqueId()));if(database!=null)database.close();}

    public void handleLevelUp(Player player,int level){player.sendMessage(message("level-up").replaceText(b->b.match("%level%").replacement(String.valueOf(level))));refreshPlayer(player);if(apollo!=null){apollo.notifyLevelUp(player,level);apollo.showCooldown(player);if(level==passManager.maxLevel())apollo.glow(player);}}
    public void refreshPlayer(Player player){nametagManager.refresh(player);if(apollo!=null){String format=getConfig().getString("nametag.format","[Nivel %level%] %player_name%");var d=passManager.get(player);if(d!=null)apollo.updateNametag(player,format.replace("%level%",String.valueOf(d.level())).replace("%player_name%",player.getName()));}}
    public Component message(String key){String p=getConfig().getString("messages.prefix","");String m=getConfig().getString("messages."+key,key);return mini.deserialize(p+m);}
    public void reloadPluginConfig(){reloadConfig();}
    public Optional<ApolloHookManager> getApollo(){return Optional.ofNullable(apollo);}
    public PassManager getPassManager(){return passManager;} public PassGUI getGui(){return gui;} public CosmeticManager getCosmeticManager(){return cosmeticManager;} public NamespacedKey getLevelKey(){return levelKey;}
}
